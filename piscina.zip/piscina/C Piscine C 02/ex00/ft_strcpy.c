/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/18 22:00:44 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/18 22:00:46 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//esta función copia TODO src a dst incluso aunque se pase el buffer de dst.

char	*ft_strcpy(char *dst, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dst[i] = src[i];
		i++;
	}
	dst[i] = '\0';
	return (dst);
}


int main (void)
{
	char a[2] = "a";
	char b[2] = "b";

	write (1, ft_strcpy(a, b), 1);
}

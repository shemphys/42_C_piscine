/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/28 02:30:59 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/28 02:31:01 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_str_is_lowercase(char *str)
{
	int i;

    i = 0;
    while (str[i] != '\0')
    {
        if (str[i] >= 97 && str[i] <= 122)
            i++;
        else
            return (0);
    }
    return (1);
}

#include <stdio.h>
int main(void)
{
    char x[] = "dfh2fghftf";
    printf("%d", ft_str_is_lowercase(x));
}
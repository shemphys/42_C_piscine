/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/24 14:07:21 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/24 14:07:24 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_len(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return(i);
}

unsigned int    ft_strlcpy(char *dest, char *src, unsigned int size)
{	//copia src en dest hasta i < size.
	//devuelve la longitud de src ¿?¿?
	unsigned int    i;
	int				x;

	x = ft_len(src);
	i = 0;
	if (src[i] != '\0')
	{
		while (i < size)
		{
			dest[i] = src[i];
			i++;
		}
		dest[i] = '\0';
	}
	return (x);
}

#include <stdio.h>
#include <string.h>
int	main(void)
{
	char a[] = "1";
	char b[7];
	printf("%d", ft_strlcpy(b, a, 6));
}

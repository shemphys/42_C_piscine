/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/24 19:04:36 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/24 19:04:38 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_hexa(char *str)
{
	int x;
	int	y;
	//voy a almacenar todas las letras para que las busque la y de los huevos
	char	a[17];

	x = 0;
	y = 0;
	a[17] = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
	x = str / 16// [0, f] pero su 1 es un 16
	y = str % 16// [0, f] pero su 1 es un 1 xD

	write (1, "\\", 1);
	write (1, a[x], 1);
	write (1, a[y], 1);
	
}

void	ft_putstr_non_printable(char *str)
{
	// n%16 y el resto pasarlo por el traductor a hexa.
	// además, tengo que añadir un backslash.
	// tip: todos los números en hexa deben ir precedidos de \

	int	i;
	int	x;

	i = x;
	i = 0;
	while (str[i] =! '\0')
	{
		if (str[i] < 32 && str[i] > 126)//si no es imprimible....
		{
			ft_hexa(str[i]);
		}
	}
}

int	main(void)
{
	char a[] = "asd4\n asd";
	ft_putstr_non_printable(a);
}
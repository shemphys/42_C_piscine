/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/24 00:58:59 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/24 00:59:00 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		i++;
	}
	return (str);
}

char	*ff(char *str, int i, int j)
{
	while (str[i] != '\0')
	{
		if (str[i] < 48 || str[i] > 57)
		{
			if (str[i] < 'a' || str[i] > 'z')
			{
				j = 1;
				i++;
			}
		}
		if (str[i] >= 42 && str[i] <= 57)
			j = 0;
		if ((j == 1) && (str[i] >= 'a' && str[i] <= 'z'))
		{
			str[i] -= 32;
			j = 0;
		}
		i++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	j;

	j = 0;
	i = 0;
	ft_lowercase(str);
	if (str[0] >= 'a' && str[0] <= 'z')
		str[0] -= 32;
	i = 1;
	ff(str, i, j);
	return (str);
}

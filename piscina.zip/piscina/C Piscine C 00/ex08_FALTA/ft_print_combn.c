/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/16 19:18:26 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/16 19:18:30 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */



void	ft_print_combn(int n)
{
	char	out[10];
	int		i;

	i = 0;
	out[0] = '0';
	while (i++ < n - 1)//muestra la combinación de menor tamaño, el mínimo
		out[i] = out[i - 1] + 1;
	while (out[0] < '0' + 10 - n && n > 0 && n < 10)//el primer número como máximo será (10-n) && acotamos la condición para que no se pase de rosca la n
	{												//usamos la primera posición del array exclusor
		if (out[n - 1] > '9')//Se pasará de rosca cuando al 9 le sumemos 1 que mostrará : en vez de un número
		{	//si hemos entrado en este bucle es porque la última posición vale : ('9'+'1')
			i = n - 2;//modificamos la i para iterar a la penúltima posición (1 a la izquierda)
			while (out[i] >= '0' + 10 - n + i)//con este bucle nos vamos a la posición siguiente (de derecha a izq), en caso e cumplir la condición
											  //cuando se cumple la condición, implica que hemos llegado al número máximo alcanzable por esa posición
				i--;
			out[i]++;//aquí sumamos 1 a la posición siguiente (de derecha a izq)
			while (i++ < n - 1)//
				out[i] = out[i - 1] + 1;
		}
		write(1, out, n);//muestra el array completo sin mostrar el fin de cadena, porque el array va de out[0] a out[10]. En out[10] = '\0'
		if (!(out[0] == '0' + 10 - n))//último número sin coma y espacio. Sin más.
			write(1, ", ", 2);
		out[n - 1]++; //suma 1 siempre al a última posición, sin contar la posición de fin de cadena, por eso el (-1)
					  //de esta forma itera de derecha a izq cada vez que llega a : (que es el resultado de '9'+'1')
	} 
}

int	main(void)
{
	ft_print_combn(9);
	return (0);
}

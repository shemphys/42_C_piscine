/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/15 19:38:46 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/15 19:45:52 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	f_pot10(int i)
{
	int	x;

	x = 1;
	while (i != 0)
	{
		x = x * 10;
		i--;
	}
	return (x);
}

void	f(char c)
{
	write(1, &c, 1);
}

void	f_lastwhile(int i, int copia)
{
	char	show;

	show = '0';
	while (i >= 0)
	{
		show = (copia / f_pot10(i)) + '0';
		f(show);
		copia = copia - ((copia / f_pot10(i)) * f_pot10(i));
		i--;
	}
}

void	ft_putnbr(int nb)
{
	int		copia;
	int		i;

	if (nb == -2147483648)
		write (1, "-2147483648", 11);
	else
	{
		copia = nb;
		i = -1;
		while (copia != 0)
		{
			copia = copia / 10;
			i++;
		}
		if (nb == 0)
			f('0');
		if (nb < 0)
		{
			f('-');
			nb = nb * -1;
		}
		copia = nb;
		f_lastwhile(i, copia);
	}
}

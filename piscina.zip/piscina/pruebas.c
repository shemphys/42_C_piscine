//cómo funciona sizeof??
//sizeof(a[4]) = 4 o a 3???
/*
int main()
{
    char a[3] = "lo\0";
    unsigned int x = sizeof (a);

}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}
*/
/*
#include <limits.h>
#include <stdio.h>
int	main(void)
{
	int	x = INT_MIN;
	printf("%d", x);
}
*/

/*
#include <stdio.h>
#include <unistd.h>
int	main (void)
{
	int j = 5;
	int i = 5;
	if (i++ == 5)
		printf("%d\n gane", i);
	if (++j == 5)
		printf("%d\n", j);
}
*/

#include <stdio.h>
int main ()
{
	int x = '\r';
	printf("%d", x);
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/18 19:16:18 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/18 19:16:20 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size) //por ahora solo compara
{
	int		i;
	int		constante;
	char	stop;

	stop = 'a';
	i = 0;
	while (constante < size)
	{
		while (i < size)
		{
			if (tab[constante] >= tab[i])
				i++;//quiero que me digas cuándo el número es superior a todos los demás
			else
			{
				i = 0;
				stop = 's'; //con esto paro este bucle y hago que itere con el siguiente
			}
				
		}
		constante++;
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcarvaja <lcarvaja@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/15 20:03:54 by lcarvaja          #+#    #+#             */
/*   Updated: 2022/08/17 19:41:38 by lcarvaja         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_reverse_alphabet(void)
{
	char	c;

	c = 123;
	while (c-- > 97)
	{
		write(1, &c, 1);
	}
}

int main ()
{
	ft_print_reverse_alphabet();
}
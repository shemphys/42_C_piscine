/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcarvaja <lcarvaja@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/15 21:13:09 by lcarvaja          #+#    #+#             */
/*   Updated: 2022/08/17 20:54:45 by lcarvaja         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_numbers(void)
{
	char	c;

	c = 47;
	while (c++ < 57)
	{
		write (1, &c, 1);
	}
}

int main ()
{
	ft_print_numbers();
}
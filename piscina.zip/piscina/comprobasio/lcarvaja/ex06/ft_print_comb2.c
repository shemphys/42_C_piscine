/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcarvaja <lcarvaja@student.42madrid.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/17 15:52:10 by lcarvaja          #+#    #+#             */
/*   Updated: 2022/08/23 15:11:24 by lcarvaja         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_comb2(void)
{
	char	n[5];
	int		a;
	int		b;

	a = 0;
	n[2] = ' ';
	while (a <= 98)
	{
		b = a + 1;
		while (b <= 99)
		{
			n[0] = a / 10 + '0';
			n[1] = a % 10 + '0';
			n[3] = b / 10 + '0';
			n[4] = b % 10 + '0';
			write(1, &n, 5);
			if (!(a == 98 && b == 99))
				write (1, ", ", 2);
			if (a == b)
				write(1, " ", 1);
		b++;
		}
	a++;
	}
}

int	main(void)
{
	ft_print_comb2();
	return (0);
}

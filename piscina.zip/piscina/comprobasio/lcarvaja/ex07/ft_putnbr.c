/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcarvaja <lcarvaja@student.42madrid.co>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/21 15:35:12 by lcarvaja          #+#    #+#             */
/*   Updated: 2022/08/23 15:21:25 by lcarvaja         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	int	n;

	if (nb != -2147483648 && nb < 0)
	{
		write(1, "-", 1);
		ft_putnbr(nb * -1);
	}
	else if (nb >= 0)
	{
		if (nb <= 9)
		{
			n = nb + '0';
			ft_putchar(n);
		}
		else
		{
			ft_putnbr (nb / 10);
			ft_putnbr (nb % 10);
		}
	}
	else
		write(1, "-2147483648", 11);
}

int	main(void)
{
	ft_putnbr(-2147483648);
	return (0);
}

#!/bin/bash
git log --format='%H' -n5

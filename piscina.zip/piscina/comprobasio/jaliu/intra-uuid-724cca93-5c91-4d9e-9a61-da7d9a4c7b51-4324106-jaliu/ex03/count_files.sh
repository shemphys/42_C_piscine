find . | wc  -l | sed 's/\ *//'

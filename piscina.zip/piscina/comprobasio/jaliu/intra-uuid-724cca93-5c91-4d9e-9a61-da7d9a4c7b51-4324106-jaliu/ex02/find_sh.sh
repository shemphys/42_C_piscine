find . -type f -iname '*.sh' | sed 's/\.sh//' | sed 's/.*\///'

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afernan2 <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/16 09:09:57 by afernan2          #+#    #+#             */
/*   Updated: 2022/08/16 14:34:30 by afernan2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

int    main(void)
{
    int    d;
    int    m;
    int    *div;
    int    *mod;
    d = 5;
    m = 10;
    div = &d;
    mod = &m;
    ft_div_mod(d, m, div, mod);
    printf("%i\n", d);
    printf("%i\n", m);
}
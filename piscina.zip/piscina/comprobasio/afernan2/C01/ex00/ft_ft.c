/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afernan2 <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/15 15:23:12 by afernan2          #+#    #+#             */
/*   Updated: 2022/08/15 15:32:02 by afernan2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ft(int *nbr)
{
	int	x;

	x = 42;
	*nbr = x;
}

int    main(void)//Esto es una comprobación
{
    int    n;//valor de nuestra funcion
    int    *p;//puntero
    n = 41;//valor que se va a dar al puntero
    p = &n;//pasamos ese valor al puntero
    printf("%d\n", *p);//Ejemplo de comprobación
    ft_ft(p);//Pasamos valor al puntero
    printf("%d\n", n);//Valor de nuestra funcion
}
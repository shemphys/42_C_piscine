/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afernan2 <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/15 15:32:13 by afernan2          #+#    #+#             */
/*   Updated: 2022/08/15 15:53:08 by afernan2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_ultimate_ft(int *********nbr)
{
	int	x;

	x = 42;
	*********nbr = x;
}

int main(void)//Comprobación
{
     int n;//variable de un entero
     int *p1;//varible puntero 1 entero
     int **p2;//varible puntero 2 entero
     int ***p3;//varible puntero 3 entero
     int ****p4;//varible puntero 4 entero
     int *****p5;//varible puntero 5 entero
     int ******p6;//varible puntero 6 entero
     int *******p7;//varible puntero 7 entero
     int ********p8;//varible puntero 8 entero
     int *********p9;//varible puntero 9 entero
     n = 333;//Asignamos valor y vamos enlzando a punteros
     p1 = &n;
     p2 = &p1;
     p3 = &p2;
     p4 = &p3;
     p5 = &p4;
     p6 = &p5;
     p7 = &p6;
     p8 = &p7;
     p9 = &p8;
     printf("%d\n", *********p9);//Imprimimos punteros
     ft_ultimate_ft(p9);//Damos valor a función
     printf("%d\n", *********p9);//Imprimimos función
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afernan2 <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/16 14:19:15 by afernan2          #+#    #+#             */
/*   Updated: 2022/08/16 14:38:35 by afernan2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int	*a, int	*b)
{
	int	x;
	int	y;

	x = *a;
	y = *b;
	*a = x / y;
	*b = x % y;
}

int    main(void)
{
    int    a;
    int    b;
    
    a = -20;
    b = 10;
    ft_ultimate_div_mod(&a, &b);
    printf("%i\n", a);
    printf("%i\n", b);
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afernan2 <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/16 17:11:54 by afernan2          #+#    #+#             */
/*   Updated: 2022/08/16 17:36:57 by afernan2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int		ver;
	int		rev;
	int		swap;

	ver = 0;
	rev = size - 1;
	while (ver < (size / 2))
	{
		swap = tab[ver];
		tab[ver] = tab[rev];
		tab[rev] = swap;
		ver++;
		rev--;
	}
}

int    main(void)
{
    int    i = 0;
    int    a[4] = {5, 7, 3, 8};
    ft_rev_int_tab(a, 4);
    while (i < 4)
    {
        printf("%d", a[i]);
        i++;
    }
}
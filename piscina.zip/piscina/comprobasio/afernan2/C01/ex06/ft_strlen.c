/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afernan2 <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/16 14:41:48 by afernan2          #+#    #+#             */
/*   Updated: 2022/08/16 14:50:33 by afernan2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char	*str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int    main(void)
{
    char    *word;
    char    a;
    word = "9999999999";
    a = ft_strlen(word);
    printf("Longitud de la palabra -> %s", word);
    printf(" es:  %d\n", a);
}
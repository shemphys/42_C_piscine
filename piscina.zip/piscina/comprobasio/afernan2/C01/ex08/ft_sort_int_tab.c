/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afernan2 <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/16 17:37:12 by afernan2          #+#    #+#             */
/*   Updated: 2022/08/16 18:12:39 by afernan2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{	
	int		swap;	
	int		count;

	count = 0;
	while (count < (size - 1))
	{
		if (tab[count] > tab[count + 1])
		{
			swap = tab[count];
			tab[count] = tab[count + 1];
			tab[count + 1] = swap;
			count = 0;
		}		
		else
			count++;
	}
}

int main (void)
{
    int i=0;int a[5] = {18,11,7,1,5}; ft_sort_int_tab(a, 5);
    while (i < 5)
    {
        printf("%d", a[i]);
        i++;
    }
}
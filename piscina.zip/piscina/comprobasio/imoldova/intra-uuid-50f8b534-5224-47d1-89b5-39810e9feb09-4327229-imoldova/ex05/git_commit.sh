#/bin/sh

comand_commit=$(git log -5 --pretty=format:"%H")
echo "$comand_commit"



/* I will xplain here every command 4 the exam */


//STRCPY
char	*ft_strcpy(char *dest, char *src)
{//this function is a pointer cuz it returns a pointer
	int	i;

	i = 0;
	while (src[i] != '\0')//copying each char into dest
	{
		dest[i] = src[i];
		i++;
	}
	src[i] = '\0';//last char will be NULL
	return (dest);//this 
}
//It will copy src into dest no matter if there is room or not

//---------------------------------//


//STRNCPY
char	*ft_strncpy(char *dest, char *src, unsigned int n)
{//copies n char from src to dest
//Si src tiene n caracteres o más, no se añade '\0'
//Si src tiene menos de n caracteres, el resto de huecos se completa con '\0'

	unsigned int	i;

	i = 0;
	while (i != n)
	{
		if (src[i] != '\0')
			dest[i] = src[i];
		else
			dest[i] = '\0';
		i++;
	}
	return (dest);
}

//---------------------------------//
//				C03
//---------------------------------//



//STRSTR
char	*ft_strstr(char *dest, char *src)
{//scan dest looking for src in it.
//if it finds it, it will return a pointer to the start of it
//returns NULL (0) if it can't find it
//CAUTION: show error if the any string don't end in '\0'


	int	i;//src index
	int	j;//dest index
	int i_temp;//la necesito para iterar dentro de dest comprobando con j
	int	dest_length;
	int	src_length;

	j = 0;
	i = 0;
	dest_length = sizeof(dest);
	src_length = sizeof(src);

	while (i < (dest_length - src_length))//definimos el espectro de dest que podemos revisar
	{//además, seleccionamos la posición de dest a estudiar
		i_temp = i;
		while (j < src_length)
		{
			if (dest[i_temp] == src[j])
			{
				if (j == )//Si es el final de la cadena src, hemos encontrado lo que bucábamos
					return (1);
				i_temp++;//iteramo
			}
			j++;
		}
		j = 0;
		i++;
	}
	return (0);//significa que no cumple la condición
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/28 06:53:35 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/28 06:53:36 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_len(char *x)
{
	int	i;

	i = 0;
	while (x[i] != '\0')
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{   //añade caracteres de src a dest
	//size -> size caracteres - 1, que corresponde a '\0'
	//dest y src deben ser NULL terminated.
	//
	unsigned int	i;//iterador de src
	unsigned int	destLen;
	unsigned int	srcLen;

	destLen = ft_len(dest);
	srcLen = ft_len(src);
	i = 0;
	if (size == 0)
		return (destLen + srcLen);//devuelve la cadena que intentamos crear
	while(src[i] != '\0' && i < size - destLen - 1)
	{
		dest[destLen + i] = src[i];
		i++;
	}
	dest[destLen + i] = '\0';
}

#include <string.h>
int	main(void)
{
	char	a[] = "xx";
	char	b[3] = "yy";
	printf("%i \n", ft_strlcat(b, a, 20));
	printf("%s \n", b);
}
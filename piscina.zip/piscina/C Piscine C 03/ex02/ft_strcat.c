/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/28 04:51:01 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/28 04:51:03 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *dest)
{
	int	i;

	i = 0;
	while (dest[i] != '\0')
		i++;
	return (i);
}

char	*ft_strcat(char *dest, char *src)
{	//añade src a dest, sin sobrescribir.
	//del final de dest en adelante.
	int	i;
	int	x;

	i = 0;
	x = ft_strlen(dest); //para sobreescribir justo el \0
	while(src[i] != '\0')
	{
		dest[x + i] = src[i];
		i++;
	}
	dest[x + i] = '\0'; //porque como paro justo en el \0 pues se lo meto después
	return (dest);
}

#include <string.h>
#include <stdio.h>
int	main(void)
{
	char	a[] = "hyha";
	char	c[5] = "xxxx";

	ft_strcat(c, a);
	char	aa[] = "hyha";
	char	bb[5] = "xxxx";
	strcat(bb, aa);
	printf("asjdbfshdkjfn");
}
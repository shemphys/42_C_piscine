/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/24 20:30:03 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/24 20:30:05 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{	//restar los char para saber si son iguales xD
	//si no son iguales, devolver la diferencia
	int	i;

	i = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		if (!(s1[i] == s2[i]))
			return (s1[i] - s2[i]);
		i++;
	}
	return (0);
}

#include <string.h>
#include <unistd.h>

int	main (void)
{
	char	s1[] = "hoa";
	char	s2[] = "hoa";
	int		x = ft_strcmp(s1, s2);
	int		y = strcmp(s1, s2);
	write(1, "\n", 1);
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/28 05:24:34 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/28 05:24:36 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_len(char *dest)
{
	unsigned int	i;

	i = 0;
	while (dest[i] != '\0')
		i++;
	return (i);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{   //añade src a dest. ¿cuántos? pues nb o hasta que se termine src

	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = ft_len(dest);
	while (i < nb && src[i] != '\0')
	{
		dest[j + i] = src[i];
		i++;
	}
	dest[j + i] = '\0';
	return (dest);
}

#include <string.h>
int	main(void)
{
	char	a[] = "aaa!a";
	char	b[10] = "bbb";
	ft_strncat(b, a, 5);
	char	aa[] = "aaa!a";
	char	bb[10] = "bbb";
	strncat(bb, aa, 5);
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/27 19:38:04 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/27 19:38:06 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{	//como la anterior pero comparando n caracteres.
	//si n = 0 -> return (0).
	//lo mismo: return (s1[i] - s2[i])
	unsigned int	i;
	
	i = 0;
	while ((s1[i] != '\0' || s2[i] != '\0') && i < n)
	{
		if (!(s1[i] == s2[i]))
			return (s1[i] - s2[i]);
		i++;
	}
	return (0);
}

#include <string.h>
#include <stdio.h>
int	main(void)
{
	char	a[] = "holaaaa";
	char	b[] = "hola";
	int x = ft_strncmp(b, a, 5);
	int y = strncmp(b, a, 5);
	printf("aaaaaaaa");
}
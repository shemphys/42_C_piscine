/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/28 05:35:44 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/28 05:35:46 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{	//devulve un char puntero a la primera coincidencia si la hubiere
	//devuelve NULL si no hay nah.
	//ambos str deben terminar en '\0'. De lo contrario, debería aparecer un error???¿?¿?
		//pa esto debería mirar que el último caracter de ambas no sea '\0'.. no? xD
		
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (to_find[j] == '\0')//la protección pa cuando el to_find no tiene valores.
		return (str);
	while (str[i] != '\0')//recorremos str
	{
		while (str[i + j] == to_find[j] && str[i + j] != '\0')
			j++;//sumamos la j aquí y así si la siguiente posición fuese el fin de cadena
		if (to_find[j] == '\0')//pues aquí lo comrpobamos y listo :D
			return (str + i);//no entiendo esto ?!=!?!=!?!? D:
		i++;//iteramos a la derecha str
		j = 0;//devolvemos j a la posición inicial
	}
	return (0);//devuelve (null) si no encuentra nada
				//la dirección de memoria estándar que no se usa
				//y se deja para estas movidas, pa que salga null.
				//al ser una función puntero, apuntará siempre a una dirección de memoria
				//por ello este return apunta a la dirección (null) de memoria.
}

#include <stdio.h>
int	main(void)
{
	char str[] = "abcdefg";
	char to_find[] = "f";
	ft_strstr(str, to_find);
	strstr(str, to_find);
	printf("%s", strstr(str, to_find));
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/29 08:55:43 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/29 08:55:45 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial (int nb)
{
	if (nb < 0)
		return (0);
    if (nb == 0)
        return (1);
	if (nb != 0)
         return (nb * ft_iterative_factorial(nb - 1));
}
int main(void)
{
	int x = ft_iterative_factorial(4);
}
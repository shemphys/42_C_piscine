/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/29 09:04:54 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/29 09:04:55 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	x;

	x = 1;
	if (nb == 0 && power == 0)
		return (1);
	while (power > 0)
	{
		x *= nb;
		power--;
	}
	return (x);
}

int	main (void)
{
	int x = ft_iterative_power(2, 3);
}
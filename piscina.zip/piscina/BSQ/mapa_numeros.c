
int main(char *map)
{
	char    map[10][10];

	int		i;//contador
	int		map_num[][];
	int     r;
	int     c;

	i = 1;
/*
	PROBLEMAS
			- primera fila
			- primera columna
*/
	while (map[r][c] != '\0')//traducir mapa a numeros
	{
		if (r == 0 || c == 0)//control para r=0
		{
			if (map[0][0] == 'o')
				map_num[0][0] = 1;
			else if (map[0][0] != 'o')
				map_num[0][0] = 0;
			while (map[0][i] != '\0')//toooda la primera fila
			{
				if (map[0][i] == 'o')
				{
					map_num[0][i] = 1 + map_num[0][i - 1];
				}
				else
					map_num[0][i] = 0 + map_num[0][i - 1];
				i++;
			}
			i = 1;
			while (map[i][0] != '\0')//rellenar la primera columna
			{
				if (map[i][0] == 'o')
				{
					map_num[i][0] = 1 + map_num[i - 1][0];
				}
				else
					map_num[i][0] = 0 + map_num[i - 1][0];
				i++;
			}
		}
		else
			ft_else(map, map_num, r, c);
	}
}

int	*ft_else(char **map, int **map_num, int r, int c)
{
	if (map[r][c] == 'o')//esto vale para todo menos para r=0 c=0
	{   //esto es pa cuando encontramos un obstáculo
		map_num[r][c] = 1 + map_num[r][c - 1] + map_num[r - 1][c] - map_num[r - 1][c - 1];
	}
	else
		map_num[r][c] = 0 + map_num[r][c - 1] + map_num[r - 1][c] - map_num[r - 1][c - 1];
}
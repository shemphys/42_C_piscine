/*
Source: https://www.youtube.com/watch?v=MtqFZRXaeM0
*/

//abres fichero
//lees fichero almacenándolo en un array (aunque se puede hacer sin almacenar)
//lo cierras.

#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int	main(void)
{
	int		fd;
	char	buf[30];//a este array habrá que darle el tamaño con malloc
	ssize_t nr_bytes; //signed size_t, que puede devolver -1

	fd = open ("/Users/mparedes/Documents/BSQ/leer ficheros/miFichero", O_RDONLY);
	// open ("path del fichero", flags);

	if (fd == -1)
	{
		printf("Error al abrir el archivo \n");
	}
	else
	{
		nr_bytes = read(fd, buf, 30);
		close(fd);
		if (nr_bytes == 0)
		{
			printf("arhivo vachi \n");
		}
		else
		{
			printf("El numero de characteres es %d , contenido: %s", (int)nr_bytes, buf);
		}
	}
	return (0);
}
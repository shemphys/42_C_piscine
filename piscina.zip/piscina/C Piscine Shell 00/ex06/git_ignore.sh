git clean -ndX | sed "s/Would remove //g"

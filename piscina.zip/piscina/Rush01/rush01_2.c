/*
Voy a colocar números según el filtro de perspectivas.
Luego le pasaré el filtro de sudoku QUE YA TENGO HECHO.

*/

voidft_perspectivas(void)
{
	if 
}

int main(argc, argc)
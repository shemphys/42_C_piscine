/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: javlopez <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/11 17:31:11 by javlopez          #+#    #+#             */
/*   Updated: 2022/08/14 12:20:55 by javlopez         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
void	ft_putchar(char c);

void	rush(int x, int y)
{
	int	f;
	int	c;

	f = 1;
	while (f <= y)
	{
		c = 1;
		while (c <= x)
		{			
			if (((f == 1) && (c == 1)) || ((f == y) && (c == 1)))
				ft_putchar ('A');
			else if (((f == 1) && (c == x)) || ((f == y) && (c == x)))
				ft_putchar ('C');
			else if ((f == 1) || (c == 1) || (f == y) || (c == x))
				ft_putchar ('B');
			else
				ft_putchar (' ');
			c++;
		}
		f++;
		if (x > 0)
			ft_putchar ('\n');
	}	
}

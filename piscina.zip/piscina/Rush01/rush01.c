#include <unistd.h>

void	sudoku_rulz(void)//sudoku rulz checker QUENOPUÉSÉVOIDxD
{
	int	M[4][4];//making the matrix

	int A[4][4];

	M[3][] = {1, 2, 3, 4};
	M[2][] = {4, 1, 2, 3};
	M[1][] = {3, 4, 1, 2};
	M[0][] = {2, 3, 4, 1};

	//time to check the sudoku norm
	
	int	r;//rows
	int c;//columns
	int r_c;//row checker
	int c_c;//column checker

	r = 0;
	c = 0;
	r_c = 0;
	c_c = 0;
	while(r < 4)//selecting row
	{
		while(c < 4)//selecting column
		{
			while(r_c < 4)//checking row
			{
				
				while(c_c < 4)//checking column
				{
					if(c_c == c)//avoiding same column
						c_c++;
					else
					{
						if(M[r_c][c_c] == M[r][c])
						{
							write(1, "Error\n", 6);
							r = 10;//with this I pretend to stop the function
							c = 10;//just a way to end everything
							r_c = 10;//since I do not have to print where the error is
							c_c = 10;//just stop uwu
						}
					}	
				}
				r_c++;
			}
			c++;
		}
		r++;
	}
}

//for now, I will set number manually, just perspectives.
//later I will go into the problem of... arguments? o.O idk yet xD
int		perspectives_rulz(void)
{
	//
}

int		matrix_generator(void)
{
	//let's make every posible variation for a 4x4 matrix
	//that meets the requisites of sudoku_rulz(void)
}


///////////////////////////


void	sudoku_rulz(void)//quiero que sea un generador de sudokus uwu
{
	int	M[4][4];//making the matrix

	M[3][] = {1, 2, 3, 4};
	M[2][] = {4, 1, 2, 3};
	M[1][] = {3, 4, 1, 2};
	M[0][] = {2, 3, 4, 1};

	//time to check the sudoku norm
	
	int	r;//rows
	int c;//columns
	int r_c;//row checker
	int c_c;//column checker

	r = 0;
	c = 0;
	r_c = 0;
	c_c = 0;
	while(r < 4)//selecting row
	{
		while(c < 4)//selecting column
		{
			while(r_c < 4)//checking row
			{
				if(r_c == r)//avoiding same row
					r_c++;
				else
				{
					while(c_c < 4)//checking column
					{
						if(c_c == c)//avoiding same column
							c_c++;
						else
						{
							if(M[r_c][c_c] == M[r][c])
							{
								write(1, "Error\n", 6);
								r = 10;//with this I pretend to stop the function
								c = 10;//just a way to end everything
								r_c = 10;//since I do not have to print where the error is
								c_c = 10;//just stop uwu
							}
						}
						
					}
					r_c++;
				}
			}
			c++;
		}
		r++;
	}
}

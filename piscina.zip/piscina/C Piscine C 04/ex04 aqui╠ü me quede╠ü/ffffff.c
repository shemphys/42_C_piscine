
void	ft_putnbr_base(int nbr, char *base)
{
	
}
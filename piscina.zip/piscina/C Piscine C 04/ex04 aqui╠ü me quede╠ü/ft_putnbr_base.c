/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/29 05:22:30 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/29 05:22:32 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr_base(int nbr, char *base)
{	//base contiene la cantidad de caracteres y los caracteres (de la base).
	//la primera posición puede ser simplemente la i xD ya que (1 número = 1 dígito)
	//nbr me lo dan en decimal y lo tengo que pasar a la otra base
	
	int		i;
	int		x; //longitud de la base
	int		y; //nbr
		
	while (a[i] != '\0')
		i++;
	x = i; //igualo x a i porque.. no sé pero para algo bueno seguro :D
	while(y / x > 0)//aquí vamos añadiendo a un string los restos del numero
		{
			a[i] = y % x;
			y = y / x;
			i++;
		}
		//falta la última posición que es el cociente que es y.
		a[i] = y;
		//y la siguiente: el '\0' que nunca está de más xD
		a[i + 1] = '\0';

}


int	main(void)
{
	int		x = 16;//cantidad de caracteres de la base
	int		y = 210631;//número en decimal a cambiar a la base
	int		a[5];//array en el que almaceno los restos
	int		i = 0;//contador
	int		num;//(aun sin usar) aquí iré multiplicando los restos 

	while(y / x > 0)//aquí vamos añadiendo a un string los restos del numero
	{
		a[i] = y % x;
		y = y / x;
		i++;
	}
	//falta la última posición que es el cociente que es y.
	a[i] = y;
	//y la siguiente: el '\0' que nunca está de más xD
	a[i + 1] = '\0';
}
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/28 07:36:10 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/28 07:36:11 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

void	ft_putchar(char c)
{
	write (1, &c, 1);
}

int ft_strlen(int nb)	//sacar aquí la longitud de nb
{						//y utilizar ft_10pot(ft_strlen(nb - 1))
	int	i;

	i = 0;
	while(nb > 0)
	{
		nb /= 10;
		i++;
	}
	return (i);
}

int	ft_10pot(int nb)
{
	long int	x;

	x = 1;
	while (nb > 0)
	{
		nb--;
		x *= 10;
	}
	return (x);
}

void	ft_putnbr(int nb)
{
	char	show;
	int		supu;

	if (nb <= 0)
	{
		if (nb == -2147483648)
			write(1, "-2147483648", 11);
		if (nb < 0 && nb != -2147483648) 
		{
			nb *= -1;
			write(1, "-", 1);
		}
		if (nb == 0)
			write(1, "0", 1);
	}
	supu = ft_strlen(nb);
	while (nb > 0)
	{
		show = (nb / ft_10pot(supu)) + '0';
		ft_putchar(show);
		nb -= (nb / ft_10pot(supu) * ft_10pot(supu));
		supu--;
	}
}

int	main(void)
{
	ft_putnbr(100000);
}

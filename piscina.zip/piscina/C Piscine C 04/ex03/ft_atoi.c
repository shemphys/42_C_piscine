/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/29 04:20:41 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/29 04:20:43 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_(char *str)
{//primero:	avanzar cuando encuentre una tabulación <= x <= etorno de carro o espacio
//segundo:	avanzar a través de los negativos y positivos && contar los negativos.
//tercero:	a partir de aquí, buscamos los números hasta que deja de haber, en ese momento termina el programa
	int	i;
	int	neg;
	int	num;

	i = 0;
	neg = 1;
	num = 0;
	while ((str[i] >= '\t' && str[i] <= '\r') || str[i] == ' ')
		i++;
	while (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			neg *= -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		num = num * 10 + str[i] - 48;
		i++;
	}
	return (num * neg);
}

#include <stdio.h>
int	main()
{
	printf("%d mi funsion\r", ft_("---+--+000001 234ab567"));
	//printf("%d iii", ("---+--+1234ab567"));
}

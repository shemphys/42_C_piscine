/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mparedes <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/27 18:01:20 by mparedes          #+#    #+#             */
/*   Updated: 2022/08/27 18:01:22 by mparedes         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	if (argc == 2)
		{
		if (argv[1][0] == '4' && argv[1][1] == '2')
			write (1, "forty two is soooo cool we wanna join uwu\n", 42);
		}
	else if (argc == 3)
		{
		if (argv[2][0] == '4' && argv[2][1] == '2')
			write (1, "forty two is soooo cool we wanna join uwu\n", 42);
		}
	else
		write (1, "Error\n", 6);
}

/*Assignment name  : ft_print_numbers
Expected files   : ft_print_numbers.c
Allowed functions: write
--------------------------------------------------------------------------------

Write a function that displays all digits in ascending order.

Your function must be declared as follows:
*/
#include <unistd.h>
void	ft_print_numbers(void)
{
    write (1, "1234567890", 10);
}
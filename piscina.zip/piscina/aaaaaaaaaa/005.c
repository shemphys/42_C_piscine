#include <unistd.h>
#include <stdio.h>
char *ft_rev_print (char *str)
{
	int		i;
	int		j;
	char	*dest;

	j = 0;
	i = 0;
	dest = malloc(sizeof(char) * 7); //también vale un 1 en el paréntesis
	while (str[i] != '\0')
		i++;
	i--;
	while (i >= 0)
	{
		dest[j] = str[i];
		i--;
		j++;
	}
	dest[j] = '\0';
	return(dest);
}

int	main(void)
{
	char a[] = "qwerty";
	ft_rev_print(a);
	printf("%s\n", a);
}
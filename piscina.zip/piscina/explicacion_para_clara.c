
void	ft_div_mod (int a, int b, int *div, int *mod)
{
	*div = (a / b);
	*mod = (a % b);
}

#include <stdio.h>
int	main(void)
{
	int	*gladis;
	int	*josefa;
	int pepe;//divisor
	int marta;//dividendo


	gladis = &pepe;
	josefa = &marta;
	pepe = 10;
	marta = 3;

	ft_div_mod(pepe, marta, gladis, josefa);
	return (0);
}